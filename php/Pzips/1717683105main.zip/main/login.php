<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: users.php");
  }
?>

<!DOCTYPE html>
<html>
<head>  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <style>
    :root {
      --dark: #615C83;
      --pink: #F0AEB6;
      --lavender: #D0CADB;
      --box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
    }

    body {
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: Arial, sans-serif;
    }

    .register {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100vh;
      background-color: transparent; 
    }

    .form.login {
      position: relative;
      background-color: #fff;
      padding: 40px;
    }

    .form.login header {
      text-align: center;
      font-size: 25px;
      font-weight: 600;
      padding-bottom: 10px;
      border-bottom: 1px solid #99cbe2;
    }

    .form.login form {
      margin: 20px 0;
    }

    .form.signup .field {
      margin-bottom: 20px;
      position: relative; 
    }

    .form.signup .field .fa-eye {
      position: absolute;
      top: 60%;
      right: 5px;
      transform: translateY(-50%);
      cursor: pointer;
      color: #999;
    }

    .form.login .field label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form.login .field input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .form.login .field input[type="submit"] {
      height: 45px;
      width: 100%;
      border: none;
      color: #fff;
      font-size: 17px;
      background: linear-gradient(90deg, var(--dark), var(--pink) 100%);
      box-shadow: var(--box-shadow); 
      border-radius: 15px;
      cursor: pointer;
      margin-top: 13px;
    }

    .form.login .link {
      text-align: center;
      margin-top: 10px;
    }

    .form.login .link a {
      color: #666;
      text-decoration: none;
    }

    .form.login .link a:hover {
      text-decoration: underline;
    }

    .half-circle {
      position: relative;
      width: 550px;
      height: 100%;
      border-radius: 500px 0 0 500px;
      background: linear-gradient(20deg, var(--dark), var(--pink) 100%);
      transform: translateX(50%);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      color: #fff;
      padding: 40px;
    }

    .half-circle h2 {
      font-size: 36px;
      margin-bottom: 10px;
    }

    .half-circle p {
      font-size: 16px;
      margin-bottom: 30px;
    }

    .half-circle .buttons {
      display: flex;
      justify-content: space-between;
      width: 100%;
    }

    .half-circle .buttons button {
      background-color: #fff;
      color: var(--dark);
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }

    .half-circle .buttons .circular-btn {
      background-color: transparent;
      border: 2px solid #fff;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .half-circle .buttons .circular-btn i {
      color: #fff;
      font-size: 20px;
    }
  </style>
</head>
<body>
  <div class="register">
    <section class="form login">
      <header>Login to MindScript</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
          <div class="field input">
            <label>Email Address</label>
            <input type="text" name="email" placeholder="Enter your email" required>
          </div>
          <div class="field input">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>
            <i class="fas fa-eye"></i>
          </div>
          <div class="field button">
            <input type="submit" name="submit" value="Login">
          </div>
      </form>
      <div class="link">Not signed up yet? <a href="signup.php">Signup now</a></div>
    </section>
    <div class="half-circle">
      <h2>Mind Script</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
      </p>
      <div class="buttons">
        <button>Mind Script</button>
        <a href="index.php" class="circular-btn">
          <i class="fas fa-arrow-right"></i>
        </a>
      </div>
    </div>
  
  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/login.js"></script>

</body>
</html>