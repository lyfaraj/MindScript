<?php
session_start();
include_once "php/config.php";

// Redirect to login page if user is not logged in
if (!isset($_SESSION['unique_id'])) {
    header("location: login.php");
    exit(); 
}

$user_id = $_SESSION['unique_id'];

if ($user_id === null) {
    die('User ID is not set.');
}

$sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = '$user_id'");

if ($sql && mysqli_num_rows($sql) > 0) {
    $row = mysqli_fetch_assoc($sql);
} else {
    die('Error fetching user data: ' . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html>
<head>
    
<link rel="stylesheet" href="chat.css">
    <style>

    </style>
</head>
<body>

<div class="wrapper">
    <section class="users">
        <div class="search">
            <span class="text">Select a user to start chat</span>
            <input type="text" placeholder="Enter name to search...">
            <button><i class="fas fa-search"></i></button>
        </div>
        <div class="users-list">
        </div>
    </section>
</div>

<script src="javascript/users.js"></script>
</body>
</html>